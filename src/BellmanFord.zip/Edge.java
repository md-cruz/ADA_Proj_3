
public interface Edge {
	
	int getWeight();
	
	int getInNode();
	
	int getOutNode();

}
