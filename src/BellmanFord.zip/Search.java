import java.util.List;

public interface Search {

	boolean bellmanFord(int originNode, int destNode);
}
